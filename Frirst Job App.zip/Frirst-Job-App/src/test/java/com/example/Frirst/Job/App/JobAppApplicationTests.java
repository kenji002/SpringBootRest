package com.example.Frirst.Job.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
